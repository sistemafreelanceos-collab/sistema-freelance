"use client";
import { useState } from "react";
import { Proveedor, ProyectoProveedor } from "../../../../types/proveedores";
import { XMarkIcon, PlusIcon, PencilIcon, TrashIcon } from "@heroicons/react/24/solid";
import ModalProyectoProveedor from "./ModalProyectoProveedor";
import ModalPagoProveedor from "./ModalPagoProveedor";

interface Props {
    proveedor: Proveedor | null;
    cuentas: any[];
    isOpen: boolean;
    onClose: () => void;
    onCrearProyecto: (proveedorId: string, data: Partial<ProyectoProveedor>) => Promise<void>;
    onEditarProyecto: (data: Partial<ProyectoProveedor> & { id: string }) => Promise<void>;
    onEliminarProyecto: (id: string) => Promise<void>;
    onRegistrarPago: (pago: any) => Promise<void>;
}

const ESTADO_STYLE: Record<string, string> = {
    pendiente: "bg-gray-500/20 text-gray-400 border-gray-500/20",
    en_progreso: "bg-blue-500/20 text-blue-300 border-blue-500/20",
    completado: "bg-emerald-500/20 text-emerald-400 border-emerald-500/20",
};
const ESTADO_LABEL: Record<string, string> = {
    pendiente: "Pendiente",
    en_progreso: "En progreso",
    completado: "Completado",
};

export default function ModalDetalleProveedor({ proveedor, cuentas, isOpen, onClose, onCrearProyecto, onEditarProyecto, onEliminarProyecto, onRegistrarPago }: Props) {
    const [modalProyecto, setModalProyecto] = useState(false);
    const [proyectoAEditar, setProyectoAEditar] = useState<ProyectoProveedor | null>(null);
    const [proyectoParaPagar, setProyectoParaPagar] = useState<ProyectoProveedor | null>(null);
    const [confirmEliminar, setConfirmEliminar] = useState<string | null>(null); // id del proyecto a eliminar

    if (!isOpen || !proveedor) return null;

    const proyectos = proveedor.proyectos_proveedor || [];
    const todosLosPagos = proveedor.pagos_proveedor || [];
    const totalPagado = todosLosPagos.filter(p => p.estado === "pagado").reduce((s, p) => s + p.monto, 0);

    const handleCrearProyecto = async (data: Partial<ProyectoProveedor>) => {
        if (proyectoAEditar) {
            await onEditarProyecto({ ...data, id: proyectoAEditar.id });
            setProyectoAEditar(null);
        } else {
            await onCrearProyecto(proveedor.id, data);
        }
        setModalProyecto(false);
    };

    const handleEliminar = async (id: string) => {
        await onEliminarProyecto(id);
        setConfirmEliminar(null);
    };

    // Build a proveedor object for ModalPagoProveedor, scoped to the selected project
    const proveedorParaPago: Proveedor | null = proyectoParaPagar
        ? {
            ...proveedor,
            moneda: proyectoParaPagar.moneda,
            pagos_proveedor: (proyectoParaPagar.pagos_proveedor || []),
        }
        : null;

    return (
        <>
            {/* Overlay */}
            <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40" onClick={onClose} />

            {/* Centered modal */}
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                <div className="bg-[#0D1117] border border-white/10 rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[90vh] animate-in fade-in zoom-in-95 duration-200">
                    {/* Header */}
                    <div className="flex justify-between items-start p-6 border-b border-white/10">
                        <div>
                            <h2 className="text-2xl font-bold text-white">{proveedor.nombre}</h2>
                            {proveedor.empresa && <p className="text-sm text-gray-400">{proveedor.empresa}</p>}
                            {proveedor.especialidad && (
                                <span className="inline-block mt-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300">
                                    {proveedor.especialidad}
                                </span>
                            )}
                        </div>
                        <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition mt-1">
                            <XMarkIcon className="w-5 h-5 text-gray-400" />
                        </button>
                    </div>

                    {/* Info rápida */}
                    <div className="px-6 py-3 border-b border-white/5 flex gap-6 text-xs text-gray-500">
                        {proveedor.email && <span>✉️ {proveedor.email}</span>}
                        {proveedor.telefono && <span>📞 {proveedor.telefono}</span>}
                        {proveedor.nit && <span>🪪 {proveedor.nit}</span>}
                    </div>

                    {/* KPI — agrupado por moneda de cada proyecto */}
                    {(() => {
                        const pagadoPorMoneda: Record<string, number> = {};
                        proyectos.forEach(proy => {
                            const mon = proy.moneda || 'USD';
                            const pagado = (proy.pagos_proveedor || [])
                                .filter(p => p.estado === 'pagado')
                                .reduce((s, p) => s + p.monto, 0);
                            pagadoPorMoneda[mon] = (pagadoPorMoneda[mon] || 0) + pagado;
                        });
                        const monedas = Object.keys(pagadoPorMoneda);

                        return (
                            <div className="grid grid-cols-2 gap-3 p-4 border-b border-white/5">
                                <div className="bg-white/5 rounded-xl p-3 text-center">
                                    <p className="text-[10px] text-gray-500 uppercase">Proyectos</p>
                                    <p className="text-2xl font-bold text-white">{proyectos.length}</p>
                                </div>
                                <div className="bg-emerald-500/5 border border-emerald-500/10 rounded-xl p-3 text-center">
                                    <p className="text-[10px] text-gray-500 uppercase mb-1">Pagado</p>
                                    {monedas.length === 0 ? (
                                        <p className="text-lg font-bold text-emerald-400 font-mono">$0</p>
                                    ) : (
                                        monedas.map(mon => (
                                            <p key={mon} className="text-base font-bold text-emerald-400 font-mono leading-tight">
                                                {new Intl.NumberFormat('es-CO', { style: 'currency', currency: mon, maximumFractionDigits: 0 }).format(pagadoPorMoneda[mon])}
                                                <span className="text-[10px] ml-1 text-emerald-700">{mon}</span>
                                            </p>
                                        ))
                                    )}
                                </div>
                            </div>
                        );
                    })()}

                    {/* Lista de proyectos */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3">
                        <div className="flex justify-between items-center mb-2">
                            <h3 className="text-sm font-bold text-gray-300 uppercase tracking-wider">Proyectos</h3>
                            <button
                                onClick={() => setModalProyecto(true)}
                                className="flex items-center gap-1.5 text-xs font-bold text-indigo-400 hover:text-indigo-300 bg-indigo-500/10 hover:bg-indigo-500/20 border border-indigo-500/20 px-3 py-1.5 rounded-full transition"
                            >
                                <PlusIcon className="w-3 h-3" /> Nuevo Proyecto
                            </button>
                        </div>

                        {proyectos.length === 0 ? (
                            <div className="text-center py-10 border border-dashed border-white/10 rounded-2xl">
                                <p className="text-4xl mb-2">📁</p>
                                <p className="text-sm text-gray-500">Sin proyectos aún</p>
                                <button
                                    onClick={() => setModalProyecto(true)}
                                    className="mt-3 text-xs font-bold text-indigo-400 hover:text-indigo-300 transition"
                                >
                                    + Agregar primer proyecto
                                </button>
                            </div>
                        ) : (
                            proyectos.map(proy => {
                                const pagadoProy = (proy.pagos_proveedor || [])
                                    .filter(p => p.estado === "pagado")
                                    .reduce((s, p) => s + p.monto, 0);
                                const pct = proy.monto > 0 ? Math.min(100, Math.round((pagadoProy / proy.monto) * 100)) : 0;
                                const fmtProy = (n: number) =>
                                    new Intl.NumberFormat("es-CO", { style: "currency", currency: proy.moneda, maximumFractionDigits: 0 }).format(n);

                                return (
                                    <div key={proy.id} className="bg-[#161B22] border border-white/10 rounded-xl p-4 hover:border-indigo-500/30 transition">
                                        <div className="flex items-start justify-between mb-3">
                                            <div className="flex-1 min-w-0">
                                                <p className="font-bold text-white text-sm">{proy.nombre}</p>
                                                {proy.descripcion && <p className="text-[11px] text-gray-500 truncate">{proy.descripcion}</p>}
                                                {proy.fecha_pago && (
                                                    <p className="text-[11px] text-indigo-400 mt-0.5">
                                                        📅 Pago: {new Date(proy.fecha_pago + 'T12:00:00').toLocaleDateString('es-CO', { day: '2-digit', month: 'short', year: 'numeric' })}
                                                    </p>
                                                )}
                                            </div>
                                            <div className="flex items-center gap-1 ml-2 flex-shrink-0">
                                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${ESTADO_STYLE[proy.estado]}`}>
                                                    {ESTADO_LABEL[proy.estado]}
                                                </span>
                                                <button
                                                    onClick={() => { setProyectoAEditar(proy); setModalProyecto(true); }}
                                                    className="p-1.5 bg-blue-500/10 text-blue-400 rounded-lg hover:bg-blue-500 hover:text-white transition"
                                                    title="Editar proyecto"
                                                >
                                                    <PencilIcon className="w-3 h-3" />
                                                </button>
                                                <button
                                                    onClick={() => setConfirmEliminar(proy.id)}
                                                    className="p-1.5 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500 hover:text-white transition"
                                                    title="Eliminar proyecto"
                                                >
                                                    <TrashIcon className="w-3 h-3" />
                                                </button>
                                            </div>
                                        </div>

                                        {/* Confirmar eliminación inline */}
                                        {confirmEliminar === proy.id && (
                                            <div className="mb-3 p-3 bg-red-500/10 border border-red-500/30 rounded-xl">
                                                <p className="text-xs text-red-300 font-bold mb-2">¿Eliminar este proyecto? Esta acción no se puede deshacer.</p>
                                                <div className="flex gap-2">
                                                    <button onClick={() => handleEliminar(proy.id)} className="flex-1 bg-red-600 hover:bg-red-500 text-white text-xs font-bold py-1.5 rounded-lg transition">Sí, eliminar</button>
                                                    <button onClick={() => setConfirmEliminar(null)} className="flex-1 bg-white/5 hover:bg-white/10 text-gray-400 text-xs font-bold py-1.5 rounded-lg transition border border-white/10">Cancelar</button>
                                                </div>
                                            </div>
                                        )}

                                        {/* Progress */}
                                        <div className="space-y-1.5 mb-3">
                                            <div className="flex justify-between text-[11px]">
                                                <span className="text-gray-400">Pagado: <span className="text-white font-bold">{fmtProy(pagadoProy)}</span></span>
                                                <span className="text-gray-400">Total: <span className="text-white font-bold">{fmtProy(proy.monto)}</span></span>
                                            </div>
                                            <div className="w-full bg-white/5 rounded-full h-2 overflow-hidden">
                                                <div
                                                    className={`h-full rounded-full transition-all duration-500 ${pct >= 100 ? 'bg-emerald-500' : pct > 0 ? 'bg-yellow-500' : 'bg-white/20'}`}
                                                    style={{ width: `${pct}%` }}
                                                />
                                            </div>
                                            <p className="text-right text-[10px] text-gray-500">{pct}%</p>
                                        </div>

                                        {/* Pay button */}
                                        {pct < 100 && (
                                            <button
                                                onClick={() => setProyectoParaPagar(proy)}
                                                className="w-full text-xs font-bold bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/30 text-indigo-300 py-2 rounded-lg transition"
                                            >
                                                💸 Registrar Pago para este Proyecto
                                            </button>
                                        )}
                                    </div>
                                );
                            })
                        )}
                    </div>

                    {/* Notas */}
                    {proveedor.notas && (
                        <div className="px-6 py-3 border-t border-white/5">
                            <p className="text-[10px] text-gray-500 uppercase font-bold mb-1">Notas</p>
                            <p className="text-xs text-gray-400">{proveedor.notas}</p>
                        </div>
                    )}
                </div>
            </div>

            {/* Sub-modales */}
            <ModalProyectoProveedor
                isOpen={modalProyecto}
                onClose={() => { setModalProyecto(false); setProyectoAEditar(null); }}
                onGuardar={handleCrearProyecto}
                proyectoEditar={proyectoAEditar || undefined}
            />

            <ModalPagoProveedor
                isOpen={!!proyectoParaPagar}
                onClose={() => setProyectoParaPagar(null)}
                proveedor={proveedorParaPago}
                montoProyecto={proyectoParaPagar?.monto}
                cuentas={cuentas}
                onRegistrar={async (pago) => {
                    await onRegistrarPago({ ...pago, proyecto_proveedor_id: proyectoParaPagar?.id });
                    setProyectoParaPagar(null);
                }}
            />
        </>
    );
}
