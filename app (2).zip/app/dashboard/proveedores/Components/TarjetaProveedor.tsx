"use client";
import { Proveedor } from "../../../../types/proveedores";
import { PencilIcon, TrashIcon } from "@heroicons/react/24/outline";

interface Props {
    proveedor: Proveedor;
    onClick: (p: Proveedor) => void;
    onEditar: (p: Proveedor) => void;
    onEliminar: (id: string) => void;
}

const ESTADO_COLOR: Record<string, string> = {
    pendiente: "text-gray-400",
    en_progreso: "text-blue-400",
    completado: "text-emerald-400",
};
const ESTADO_DOT: Record<string, string> = {
    pendiente: "bg-gray-500",
    en_progreso: "bg-blue-400",
    completado: "bg-emerald-400",
};

export default function TarjetaProveedor({ proveedor, onClick, onEditar, onEliminar }: Props) {
    const proyectos = proveedor.proyectos_proveedor || [];

    // Totales pagados agrupados por moneda del proyecto
    const pagadoPorMoneda: Record<string, number> = {};
    proyectos.forEach(proy => {
        const mon = proy.moneda || "USD";
        const pagado = (proy.pagos_proveedor || [])
            .filter(p => p.estado === "pagado")
            .reduce((s, p) => s + p.monto, 0);
        pagadoPorMoneda[mon] = (pagadoPorMoneda[mon] || 0) + pagado;
    });

    const proyectosActivos = proyectos.filter(p => p.estado !== "completado").length;

    return (
        <div
            className="bg-[#161B22] border border-white/10 rounded-2xl p-5 flex flex-col gap-4 hover:border-indigo-500/40 transition group cursor-pointer"
            onClick={() => onClick(proveedor)}
        >
            {/* Header */}
            <div className="flex justify-between items-start">
                <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-white text-lg truncate">{proveedor.nombre}</h3>
                    {proveedor.empresa && (
                        <p className="text-xs text-gray-400 truncate">{proveedor.empresa}</p>
                    )}
                </div>
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition" onClick={e => e.stopPropagation()}>
                    <button
                        onClick={() => onEditar(proveedor)}
                        className="p-1.5 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition"
                    >
                        <PencilIcon className="w-4 h-4" />
                    </button>
                    <button
                        onClick={() => onEliminar(proveedor.id)}
                        className="p-1.5 rounded-lg hover:bg-red-500/20 text-gray-400 hover:text-red-400 transition"
                    >
                        <TrashIcon className="w-4 h-4" />
                    </button>
                </div>
            </div>

            {/* Proyectos lista */}
            {proyectos.length === 0 ? (
                <div className="border border-dashed border-white/10 rounded-xl p-3 text-center">
                    <p className="text-xs text-gray-600">Sin proyectos · haz clic para agregar</p>
                </div>
            ) : (
                <div className="space-y-2">
                    {proyectos.map(proy => {
                        const pagado = (proy.pagos_proveedor || [])
                            .filter(p => p.estado === "pagado")
                            .reduce((s, p) => s + p.monto, 0);
                        const pct = proy.monto > 0 ? Math.min(100, Math.round((pagado / proy.monto) * 100)) : 0;
                        const fmt = (n: number) =>
                            new Intl.NumberFormat("es-CO", { style: "currency", currency: proy.moneda || "USD", maximumFractionDigits: 0 }).format(n);

                        return (
                            <div key={proy.id} className="bg-black/20 rounded-xl px-3 py-2.5">
                                <div className="flex justify-between items-center mb-1.5">
                                    <div className="flex items-center gap-1.5 min-w-0">
                                        <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${ESTADO_DOT[proy.estado] || 'bg-gray-500'}`} />
                                        <p className={`text-xs font-bold truncate ${ESTADO_COLOR[proy.estado] || 'text-gray-400'}`}>{proy.nombre}</p>
                                    </div>
                                    <span className="text-[10px] text-gray-500 ml-2 flex-shrink-0">{pct}%</span>
                                </div>
                                <div className="w-full bg-white/5 rounded-full h-1.5 overflow-hidden">
                                    <div
                                        className={`h-full rounded-full ${pct >= 100 ? 'bg-emerald-500' : pct > 0 ? 'bg-yellow-400' : 'bg-white/10'}`}
                                        style={{ width: `${pct}%` }}
                                    />
                                </div>
                                <div className="flex justify-between mt-1 text-[10px] text-gray-600">
                                    <span>{fmt(pagado)}</span>
                                    <span>{fmt(proy.monto)}</span>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* Totales pagados por moneda */}
            {Object.keys(pagadoPorMoneda).length > 0 && (
                <div className="border-t border-white/5 pt-3 flex flex-wrap gap-2">
                    {Object.entries(pagadoPorMoneda).map(([mon, total]) => (
                        <span key={mon} className="text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded-full font-bold font-mono">
                            {new Intl.NumberFormat("es-CO", { style: "currency", currency: mon, maximumFractionDigits: 0 }).format(total)} pagado
                        </span>
                    ))}
                </div>
            )}

            {/* Contact */}
            {(proveedor.email || proveedor.telefono) && (
                <div className="text-[11px] text-gray-500 space-y-0.5 border-t border-white/5 pt-2">
                    {proveedor.email && <p>✉️ {proveedor.email}</p>}
                    {proveedor.telefono && <p>📞 {proveedor.telefono}</p>}
                </div>
            )}

            <p className="text-[10px] text-gray-600 text-center">Clic para pagos y detalles →</p>
        </div>
    );
}
