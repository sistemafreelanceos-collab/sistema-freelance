export default function Proyectos() {
  // Esto es como tu base de datos temporal
  const misProyectos = [
    {
      titulo: "Omar System 1.0",
      tecnologia: "Next.js + Tailwind",
      estado: "🔥 En Desarrollo",
      descripcion: "El sistema que me sacará de Latinoamérica."
    },
    {
      titulo: "Gestor de Clientes",
      tecnologia: "React + Node",
      estado: "📅 Pendiente",
      descripcion: "Para cuando tenga tantos clientes que no recuerde sus nombres."
    },
    {
      titulo: "Bot de Trading",
      tecnologia: "Python",
      estado: "💭 Idea",
      descripcion: "Para que el dinero trabaje mientras duermo en Florianópolis."
    }
  ];

  return (
    <main className="min-h-screen p-24 bg-gray-900 text-white">
      <h1 className="text-4xl font-bold text-emerald-400 mb-8">🛠️ Mis Proyectos</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Aquí ocurre la magia: El Loop automático */}
        {misProyectos.map((proyecto, index) => (
          <div key={index} className="bg-gray-800 p-6 rounded-xl border border-gray-700 hover:border-emerald-500 transition cursor-pointer">
            <div className="flex justify-between items-start mb-4">
              <h2 className="text-xl font-bold text-white">{proyecto.titulo}</h2>
              <span className="text-xs bg-emerald-900 text-emerald-300 px-2 py-1 rounded">
                {proyecto.estado}
              </span>
            </div>
            <p className="text-gray-400 mb-4 text-sm">{proyecto.descripcion}</p>
            <p className="text-xs text-gray-500 font-mono">Tecnología: {proyecto.tecnologia}</p>
          </div>
        ))}
      </div>
    </main>
  );
}