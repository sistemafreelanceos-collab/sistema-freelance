"use client";
import { useState, useEffect } from "react";

// --- TIPOS ---
type Tarea = {
  id: number;
  titulo: string;
  fecha: string;
  etiqueta: "Urgente" | "Diseño" | "Dev" | "Reunión";
  tiempoRegistrado: number; // en minutos
  enProgreso: boolean;
};

type Cliente = {
  id: number;
  nombre: string;
  servicio: string;
  pendiente: number;
};

export default function TaskMasterPro() {
  const [modulo, setModulo] = useState(1);
  const [vistaCalendario, setVistaCalendario] = useState<"mes" | "lista">("mes");
  
  // DATOS MÓDULO 1: TAREAS (Estilo Notion)
  const [tareas, setTareas] = useState<Tarea[]>([
    { id: 1, titulo: "Diseñar UI App", fecha: "2026-01-12", etiqueta: "Diseño", tiempoRegistrado: 120, enProgreso: false },
    { id: 2, titulo: "Reunión Gabriela", fecha: "2026-01-12", etiqueta: "Reunión", tiempoRegistrado: 0, enProgreso: false },
    { id: 3, titulo: "Fix Bugs Vercel", fecha: "2026-01-15", etiqueta: "Dev", tiempoRegistrado: 45, enProgreso: true }, // Tarea activa
  ]);

  // DATOS MÓDULO 2: CLIENTES
  const [clientes] = useState<Cliente[]>([
    { id: 1, nombre: "Gabriela Boutique", servicio: "E-Commerce", pendiente: 500 },
    { id: 2, nombre: "Taller Juan", servicio: "Landing Page", pendiente: 0 },
  ]);

  // Simulador de Time Tracker (efecto visual)
  useEffect(() => {
    const intervalo = setInterval(() => {
      setTareas(current => current.map(t => 
        t.enProgreso ? { ...t, tiempoRegistrado: t.tiempoRegistrado + 1 } : t
      ));
    }, 60000); // Suma 1 minuto cada minuto real (simulado)
    return () => clearInterval(intervalo);
  }, []);

  const toggleTimer = (id: number) => {
    setTareas(tareas.map(t => t.id === id ? { ...t, enProgreso: !t.enProgreso } : t));
  };

  const getColorEtiqueta = (tag: string) => {
    switch(tag) {
      case "Urgente": return "bg-red-500/20 text-red-300 border-red-500/30";
      case "Diseño": return "bg-purple-500/20 text-purple-300 border-purple-500/30";
      case "Dev": return "bg-blue-500/20 text-blue-300 border-blue-500/30";
      case "Reunión": return "bg-yellow-500/20 text-yellow-300 border-yellow-500/30";
      default: return "bg-gray-700 text-gray-300";
    }
  };

  const formatearTiempo = (minutos: number) => {
    const h = Math.floor(minutos / 60);
    const m = minutos % 60;
    return `${h}h ${m}m`;
  };

  return (
    <div className="flex h-screen bg-[#191919] text-[#E3E3E3] font-sans overflow-hidden selection:bg-[#2EAADC] selection:text-white">
      
      {/* --- SIDEBAR MINIMALISTA --- */}
      <aside className="w-64 bg-[#202020] border-r border-[#2F2F2F] flex flex-col">
        <div className="p-4 flex items-center gap-2 border-b border-[#2F2F2F]">
          <div className="w-6 h-6 bg-gradient-to-tr from-emerald-500 to-cyan-500 rounded flex items-center justify-center font-bold text-xs text-black">TM</div>
          <span className="font-semibold text-sm">Gabriela's Workspace</span>
        </div>
        
        <nav className="p-2 space-y-0.5 text-sm font-medium">
          <button onClick={() => setModulo(1)} className={`w-full flex items-center gap-3 px-3 py-2 rounded transition ${modulo === 1 ? 'bg-[#37352F] text-white' : 'text-[#9B9B9B] hover:bg-[#2C2C2C]'}`}>
            <span>📅</span> Planner & Tracker
          </button>
          <button onClick={() => setModulo(2)} className={`w-full flex items-center gap-3 px-3 py-2 rounded transition ${modulo === 2 ? 'bg-[#37352F] text-white' : 'text-[#9B9B9B] hover:bg-[#2C2C2C]'}`}>
            <span>👥</span> Clientes & Facturas
          </button>
          <button onClick={() => setModulo(3)} className={`w-full flex items-center gap-3 px-3 py-2 rounded transition ${modulo === 3 ? 'bg-[#37352F] text-white' : 'text-[#9B9B9B] hover:bg-[#2C2C2C]'}`}>
            <span>💰</span> Finanzas
          </button>
          <button onClick={() => setModulo(4)} className={`w-full flex items-center gap-3 px-3 py-2 rounded transition ${modulo === 4 ? 'bg-[#37352F] text-white' : 'text-[#9B9B9B] hover:bg-[#2C2C2C]'}`}>
            <span>🥗</span> Hábitos
          </button>
          <button onClick={() => setModulo(5)} className={`w-full flex items-center gap-3 px-3 py-2 rounded transition ${modulo === 5 ? 'bg-[#37352F] text-white' : 'text-[#9B9B9B] hover:bg-[#2C2C2C]'}`}>
            <span>📈</span> Estadísticas
          </button>
        </nav>
      </aside>

      {/* --- ÁREA PRINCIPAL --- */}
      <main className="flex-1 flex flex-col overflow-hidden bg-[#191919]">
        
        {/* HEADER TIPO NOTION */}
        <header className="h-12 flex items-center justify-between px-6 border-b border-[#2F2F2F]">
           <div className="flex items-center gap-2 text-sm">
             <span className="opacity-50">TaskMaster</span>
             <span className="opacity-50">/</span>
             <span className="font-medium text-white">
               {modulo === 1 ? 'Calendario General' : modulo === 2 ? 'Base de Datos Clientes' : 'Panel Principal'}
             </span>
           </div>
           <div className="flex gap-3">
             <button className="text-xs hover:bg-[#2C2C2C] px-2 py-1 rounded transition">Share</button>
             <button className="text-xs hover:bg-[#2C2C2C] px-2 py-1 rounded transition">Updates</button>
             <button className="text-xs hover:bg-[#2C2C2C] px-2 py-1 rounded transition">Favorite</button>
           </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8">
          
          {/* === MÓDULO 1: CALENDARIO ESTILO NOTION + TIME TRACKER === */}
          {modulo === 1 && (
            <div className="max-w-6xl mx-auto">
              {/* Toolbar */}
              <div className="flex justify-between items-center mb-6">
                <h1 className="text-3xl font-bold">Enero 2026</h1>
                <div className="flex gap-2">
                  <button onClick={() => setVistaCalendario("mes")} className={`px-3 py-1 text-sm rounded border ${vistaCalendario === 'mes' ? 'bg-[#2EAADC] border-[#2EAADC] text-white' : 'border-[#2F2F2F] hover:bg-[#2C2C2C]'}`}>Mes</button>
                  <button onClick={() => setVistaCalendario("lista")} className={`px-3 py-1 text-sm rounded border ${vistaCalendario === 'lista' ? 'bg-[#2EAADC] border-[#2EAADC] text-white' : 'border-[#2F2F2F] hover:bg-[#2C2C2C]'}`}>Lista</button>
                  <button className="bg-[#2EAADC] text-white px-3 py-1 text-sm rounded font-medium ml-2">Nuevo +</button>
                </div>
              </div>

              {/* GRID CALENDARIO */}
              {vistaCalendario === "mes" && (
                <div className="grid grid-cols-7 border-l border-t border-[#2F2F2F] bg-[#191919]">
                  {['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'].map(d => (
                    <div key={d} className="p-2 border-r border-b border-[#2F2F2F] text-xs font-semibold text-[#9B9B9B] bg-[#202020]">{d}</div>
                  ))}
                  
                  {Array.from({length: 31}, (_, i) => i + 1).map(dia => {
                     // Filtramos tareas por día (simulado)
                     const diaStr = `2026-01-${dia.toString().padStart(2, '0')}`;
                     const tareasDelDia = tareas.filter(t => t.fecha === diaStr);
                     
                     return (
                      <div key={dia} className="min-h-[120px] p-2 border-r border-b border-[#2F2F2F] hover:bg-[#202020] transition group relative">
                        <span className={`text-xs font-medium ${dia === 12 ? 'bg-red-500 text-white w-5 h-5 flex items-center justify-center rounded-full' : 'text-[#9B9B9B]'}`}>{dia}</span>
                        
                        <div className="mt-2 space-y-1">
                          {tareasDelDia.map(tarea => (
                            <div key={tarea.id} className="bg-[#2C2C2C] hover:bg-[#37352F] p-2 rounded shadow-sm border border-[#3F3F3F] cursor-pointer group/card">
                              <div className="flex justify-between items-start mb-1">
                                <span className={`text-[10px] px-1.5 rounded border ${getColorEtiqueta(tarea.etiqueta)}`}>{tarea.etiqueta}</span>
                                {tarea.enProgreso && <span className="animate-pulse w-2 h-2 rounded-full bg-green-500"></span>}
                              </div>
                              <p className="text-xs font-medium truncate mb-1">{tarea.titulo}</p>
                              
                              {/* TIME TRACKER INTEGRADO */}
                              <div className="flex items-center justify-between mt-2 pt-1 border-t border-[#3F3F3F]/50">
                                <span className="text-[10px] text-gray-400 font-mono">{formatearTiempo(tarea.tiempoRegistrado)}</span>
                                <button 
                                  onClick={(e) => { e.stopPropagation(); toggleTimer(tarea.id); }}
                                  className={`text-[10px] px-2 py-0.5 rounded transition ${tarea.enProgreso ? 'bg-red-500/20 text-red-400' : 'bg-[#3F3F3F] hover:bg-white/10'}`}
                                >
                                  {tarea.enProgreso ? '⏹ Stop' : '▶ Start'}
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                        {/* Botón flotante para añadir al día */}
                        <button className="hidden group-hover:flex absolute top-2 right-2 w-5 h-5 items-center justify-center rounded hover:bg-[#37352F] text-gray-400 text-xs">+</button>
                      </div>
                     );
                  })}
                </div>
              )}
            </div>
          )}

          {/* === MÓDULO 2: CLIENTES + FACTURAS === */}
          {modulo === 2 && (
            <div className="max-w-4xl mx-auto space-y-6">
              <h1 className="text-3xl font-bold mb-6">Clientes</h1>
              
              <div className="bg-[#202020] border border-[#2F2F2F] rounded-lg overflow-hidden">
                <table className="w-full text-left text-sm">
                  <thead className="bg-[#252525] text-[#9B9B9B] border-b border-[#2F2F2F]">
                    <tr>
                      <th className="p-3 font-normal">Nombre</th>
                      <th className="p-3 font-normal">Servicio</th>
                      <th className="p-3 font-normal">Pendiente de Pago</th>
                      <th className="p-3 font-normal">Acciones</th>
                    </tr>
                  </thead>
                  <tbody>
                    {clientes.map(c => (
                      <tr key={c.id} className="border-b border-[#2F2F2F] hover:bg-[#2C2C2C]">
                        <td className="p-3 font-medium flex items-center gap-2">
                          <span className="text-lg">📄</span> {c.nombre}
                        </td>
                        <td className="p-3 text-gray-400"><span className="bg-[#37352F] px-1.5 rounded text-gray-300">{c.servicio}</span></td>
                        <td className="p-3 text-emerald-400 font-mono">${c.pendiente}</td>
                        <td className="p-3">
                          {/* BOTÓN GENERADOR DE FACTURAS */}
                          <button className="flex items-center gap-2 bg-[#2EAADC]/10 text-[#2EAADC] hover:bg-[#2EAADC]/20 px-3 py-1.5 rounded text-xs font-medium transition">
                            <span>🧾</span> Generar Cuenta Cobro
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="p-4 border border-dashed border-gray-700 rounded-lg text-center text-gray-500 hover:border-gray-500 hover:text-gray-300 cursor-pointer transition">
                + Nuevo Cliente
              </div>
            </div>
          )}

          {/* Placeholders para los otros módulos */}
          {(modulo >= 3) && (
            <div className="flex flex-col items-center justify-center h-full text-center opacity-50">
              <div className="text-6xl mb-4">{modulo === 3 ? '💰' : modulo === 4 ? '🥗' : '📈'}</div>
              <h2 className="text-2xl font-bold">Módulo {modulo === 3 ? 'Finanzas' : modulo === 4 ? 'Hábitos' : 'Estadísticas'}</h2>
              <p>Aquí irá el contenido diseñado previamente.</p>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}