import Link from 'next/link';

export default function Navbar() {
  return (
    <nav className="flex justify-between items-center p-4 bg-gray-950 text-white border-b border-gray-800">
      <div className="text-xl font-bold text-emerald-400">
        🚀 OmarDev
      </div>
      <div className="space-x-6">
        <Link href="/" className="hover:text-emerald-400 transition">
          Inicio
        </Link><Link href="/clientes" className="hover:text-emerald-400 transition">
    Clientes
  </Link>

        <Link href="/proyectos" className="hover:text-emerald-400 transition">
          Mis Proyectos
        </Link>
        <Link href="/finanzas" className="hover:text-emerald-400 transition">
          Finanzas ($2.5k)
        </Link>
      </div>
    </nav>
  );
}