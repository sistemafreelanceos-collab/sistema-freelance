"use client";
import { useState } from "react";

export function ChatIA({ nombreCliente }: { nombreCliente: string }) {
  const [mensaje, setMensaje] = useState("");
  const [respuesta, setRespuesta] = useState("");
  const [cargando, setCargando] = useState(false);

  const enviarMensaje = async () => {
    if (!mensaje.trim()) return;
    setCargando(true);
    
    // SIMULACIÓN: Hacemos como que pensamos 1 segundo
    setTimeout(() => {
      setRespuesta(`(IA en Mantenimiento): Recibí tu mensaje: "${mensaje}". Pronto seré más inteligente.`);
      setMensaje("");
      setCargando(false);
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-xl border border-gray-700 p-4">
      <div className="flex-1 mb-4 overflow-y-auto min-h-[200px] bg-gray-950 rounded p-4 border border-gray-800">
        {respuesta ? (
          <p className="text-emerald-100 whitespace-pre-wrap">🤖 {respuesta}</p>
        ) : (
          <p className="text-gray-600 text-center italic mt-10">
            Asistente de {nombreCliente} (Desconectado temporalmente)
          </p>
        )}
        {cargando && <p className="text-emerald-500 animate-pulse text-center mt-4">Procesando...</p>}
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          className="flex-1 bg-gray-800 border border-gray-600 rounded p-2 text-white outline-none focus:border-emerald-500"
          placeholder="Escribe algo..."
          value={mensaje}
          onChange={(e) => setMensaje(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && enviarMensaje()}
        />
        <button onClick={enviarMensaje} className="bg-gray-600 text-white px-4 py-2 rounded font-bold">Enviar</button>
      </div>
    </div>
  );
}