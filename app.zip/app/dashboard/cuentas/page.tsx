"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "../../../lib/supabaseClient";

type Moneda = "USD" | "COP" | "EUR" | "MXN";

type Cuenta = {
  id: string;
  owner_id: string;
  nombre: string;
  banco: string | null;
  tipo: string | null;
  numero: string | null;
  moneda: Moneda;
  is_principal: boolean;
  created_at: string;
};

export default function CuentasPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [cuentas, setCuentas] = useState<Cuenta[]>([]);
  const [query, setQuery] = useState("");

  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({
    nombre: "",
    banco: "",
    tipo: "",
    numero: "",
    moneda: "COP" as Moneda,
    is_principal: false,
  });

  const cuentasFiltradas = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return cuentas;
    return cuentas.filter((c) => {
      return (
        c.nombre.toLowerCase().includes(q) ||
        (c.banco ?? "").toLowerCase().includes(q) ||
        (c.tipo ?? "").toLowerCase().includes(q) ||
        (c.numero ?? "").toLowerCase().includes(q)
      );
    });
  }, [cuentas, query]);

  useEffect(() => {
    const init = async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData.session;

      if (!session) {
        router.push("/");
        return;
      }

      const { data, error } = await supabase
        .from("cuentas")
        .select("*")
        .order("is_principal", { ascending: false })
        .order("created_at", { ascending: false });

      if (error) {
        console.error(error);
        alert("No se pudieron cargar las cuentas: " + error.message);
        setLoading(false);
        return;
      }

      setCuentas((data as Cuenta[]) ?? []);
      setLoading(false);
    };

    init();
  }, [router]);

  const resetForm = () => {
    setForm({
      nombre: "",
      banco: "",
      tipo: "",
      numero: "",
      moneda: "COP",
      is_principal: false,
    });
  };

  const abrirModal = () => {
    resetForm();
    setFormOpen(true);
  };

  const cerrarModal = () => {
    setFormOpen(false);
  };

  const crearCuenta = async () => {
    if (!form.nombre.trim()) {
      alert("El nombre es obligatorio (ej: Bancolombia Ahorros / Nequi).");
      return;
    }

    setSaving(true);

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData.session;
    if (!session) {
      setSaving(false);
      router.push("/");
      return;
    }

    // Si marca principal, primero quitamos principal a las demás
    if (form.is_principal) {
      const { error: resetError } = await supabase
        .from("cuentas")
        .update({ is_principal: false })
        .eq("owner_id", session.user.id);

      if (resetError) {
        setSaving(false);
        alert("No se pudo actualizar cuenta principal: " + resetError.message);
        return;
      }
    }

    const payload = {
      owner_id: session.user.id,
      nombre: form.nombre.trim(),
      banco: form.banco.trim() || null,
      tipo: form.tipo.trim() || null,
      numero: form.numero.trim() || null,
      moneda: form.moneda,
      is_principal: form.is_principal,
    };

    const { data, error } = await supabase
      .from("cuentas")
      .insert(payload)
      .select("*")
      .single();

    setSaving(false);

    if (error) {
      console.error(error);
      alert("Error creando cuenta: " + error.message);
      return;
    }

    // Insertar arriba (y si es principal, quedará destacada)
    const nueva = data as Cuenta;
    setCuentas((prev) => {
      const next = [nueva, ...prev.filter((c) => c.id !== nueva.id)];
      // Reorden: principal primero
      return next.sort((a, b) => Number(b.is_principal) - Number(a.is_principal));
    });

    cerrarModal();
  };

  const eliminarCuenta = async (id: string) => {
    if (!confirm("¿Eliminar esta cuenta?")) return;

    const { error } = await supabase.from("cuentas").delete().eq("id", id);

    if (error) {
      alert("No se pudo eliminar: " + error.message);
      return;
    }

    setCuentas((prev) => prev.filter((c) => c.id !== id));
  };

  const setPrincipal = async (cuenta: Cuenta) => {
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData.session;
    if (!session) {
      router.push("/");
      return;
    }

    // Quitar principal a todas
    const { error: resetError } = await supabase
      .from("cuentas")
      .update({ is_principal: false })
      .eq("owner_id", session.user.id);

    if (resetError) {
      alert(resetError.message);
      return;
    }

    // Poner principal a esta
    const { error } = await supabase.from("cuentas").update({ is_principal: true }).eq("id", cuenta.id);

    if (error) {
      alert(error.message);
      return;
    }

    setCuentas((prev) =>
      prev
        .map((c) => (c.id === cuenta.id ? { ...c, is_principal: true } : { ...c, is_principal: false }))
        .sort((a, b) => Number(b.is_principal) - Number(a.is_principal))
    );
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto">
        <div className="bg-[#161B22] border border-white/10 rounded-2xl p-8 text-gray-300">
          Cargando cuentas...
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <div className="flex items-center gap-4">
          <Link
            href="/dashboard"
            className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition text-gray-400"
          >
            ←
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white">Cuentas</h1>
            <p className="text-gray-400 text-sm">Registra tus bancos/cuentas para recibir pagos.</p>
          </div>
        </div>

        <button
          onClick={abrirModal}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-3 rounded-xl transition"
        >
          + Nueva cuenta
        </button>
      </div>

      {/* Search */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl p-4 mb-6">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar por nombre, banco, tipo o número..."
          className="w-full bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
        />
      </div>

      {/* List */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-white font-bold">Listado</h3>
          <span className="text-xs text-gray-400">{cuentasFiltradas.length} resultados</span>
        </div>

        {cuentasFiltradas.length === 0 ? (
          <div className="p-8 text-gray-400">No has creado cuentas todavía.</div>
        ) : (
          <div className="divide-y divide-white/10">
            {cuentasFiltradas.map((c) => (
              <div key={c.id} className="p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-bold">{c.nombre}</p>
                    {c.is_principal && (
                      <span className="text-[10px] px-2 py-1 rounded-full border bg-yellow-500/10 text-yellow-200 border-yellow-500/30">
                        principal
                      </span>
                    )}
                    <span className="text-[10px] px-2 py-1 rounded-full border bg-white/5 text-gray-200 border-white/10">
                      {c.moneda}
                    </span>
                  </div>

                  <p className="text-sm text-gray-400">
                    {(c.banco ?? "—")} • {(c.tipo ?? "—")} • {(c.numero ?? "—")}
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {!c.is_principal && (
                    <button
                      onClick={() => setPrincipal(c)}
                      className="text-xs px-3 py-2 rounded-lg border border-yellow-500/30 text-yellow-200 hover:bg-yellow-500/10 transition"
                    >
                      Hacer principal
                    </button>
                  )}

                  <button
                    onClick={() => eliminarCuenta(c.id)}
                    className="text-xs px-3 py-2 rounded-lg border border-red-500/30 text-red-300 hover:bg-red-500/10 transition"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL */}
      {formOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-xl bg-[#161B22] border border-white/10 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Nueva cuenta</h3>
              <button onClick={cerrarModal} className="text-gray-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                value={form.nombre}
                onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                placeholder="Nombre (ej: Bancolombia Ahorros, Nequi)"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <select
                value={form.moneda}
                onChange={(e) => setForm({ ...form, moneda: e.target.value as Moneda })}
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              >
                <option value="COP">COP</option>
                <option value="USD">USD</option>
                <option value="EUR">EUR</option>
                <option value="MXN">MXN</option>
              </select>

              <input
                value={form.banco}
                onChange={(e) => setForm({ ...form, banco: e.target.value })}
                placeholder="Banco (opcional)"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={form.tipo}
                onChange={(e) => setForm({ ...form, tipo: e.target.value })}
                placeholder="Tipo (ahorros / corriente / billetera)"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={form.numero}
                onChange={(e) => setForm({ ...form, numero: e.target.value })}
                placeholder="Número / Alias (opcional)"
                className="md:col-span-2 bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <label className="md:col-span-2 flex items-center gap-3 text-sm text-gray-300">
                <input
                  type="checkbox"
                  checked={form.is_principal}
                  onChange={(e) => setForm({ ...form, is_principal: e.target.checked })}
                />
                Marcar como cuenta principal
              </label>
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button
                onClick={cerrarModal}
                className="px-4 py-2 rounded-lg border border-white/10 text-gray-200 hover:bg-white/5 transition"
              >
                Cancelar
              </button>
              <button
                onClick={crearCuenta}
                disabled={saving}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition disabled:opacity-60"
              >
                {saving ? "Guardando..." : "Guardar"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
