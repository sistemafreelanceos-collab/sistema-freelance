"use client";

import { useEffect, useState, useMemo } from "react";
import { supabase } from "../../../lib/supabaseClient";

// --- TIPOS ---
type Movimiento = {
  id: string;
  fecha: string;
  descripcion: string; 
  monto: number;
  moneda: string;
  tipo: "ingreso" | "egreso";
  fuente: string;
  referencia?: string;
  nota?: string;
  categoria?: string;
  cliente?: { nombre: string } | null;
  cuenta?: { nombre: string } | null;
  cuenta_id?: string;
};

type Cuenta = {
  id: string;
  nombre: string;
  moneda: string;
};

export default function FinanzasPage() {
  const [movimientos, setMovimientos] = useState<Movimiento[]>([]);
  const [cuentas, setCuentas] = useState<Cuenta[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtro, setFiltro] = useState<"todos" | "ingreso" | "egreso">("todos");

  // Estados del Modal
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    tipo: "egreso",
    monto: "",
    moneda: "COP",
    fecha: new Date().toISOString().slice(0, 10),
    descripcion: "",
    categoria: "general",
    cuenta_id: ""
  });

  // --- CARGA DE DATOS ---
  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    setLoading(true);
    const { data: { session } } = await supabase.auth.getSession();
    if (!session) return;

    // A. Traer Movimientos (Aumentamos el límite para cubrir el mes completo)
    const { data: dataMovs, error: errorMovs } = await supabase
      .from("movimientos")
      .select(`
        *,
        cliente:clientes(nombre),
        cuenta:cuentas(nombre)
      `)
      .eq("owner_id", session.user.id)
      .order("fecha", { ascending: false })
      .limit(500); // Traemos suficiente historia

    // B. Traer Cuentas
    const { data: dataCuentas } = await supabase
      .from("cuentas")
      .select("id, nombre, moneda")
      .eq("owner_id", session.user.id);

    if (errorMovs) console.error("Error finanzas:", errorMovs);
    
    if (dataMovs) setMovimientos(dataMovs as any[]);
    if (dataCuentas) setCuentas(dataCuentas as Cuenta[]);
    
    setLoading(false);
  };

  // --- CÁLCULOS DEL MES ACTUAL ---
  const { totalIngresosMes, totalEgresosMes, rentabilidadMes, nombreMes } = useMemo(() => {
    const hoy = new Date();
    const mesActual = hoy.getMonth(); // 0 = Enero
    const anioActual = hoy.getFullYear();

    // Filtramos solo movimientos de ESTE mes y año
    const movsDelMes = movimientos.filter(m => {
        // Truco para evitar problemas de zona horaria al parsear 'YYYY-MM-DD'
        const [y, month, d] = m.fecha.split('-').map(Number);
        return (month - 1) === mesActual && y === anioActual;
    });

    // Sumas
    const ingresos = movsDelMes
        .filter(m => m.tipo === "ingreso")
        .reduce((sum, m) => sum + m.monto, 0);
        
    const egresos = movsDelMes
        .filter(m => m.tipo === "egreso")
        .reduce((sum, m) => sum + m.monto, 0);

    const nombre = hoy.toLocaleString('es-ES', { month: 'long' }); // "Enero", "Febrero"...

    return {
        totalIngresosMes: ingresos,
        totalEgresosMes: egresos,
        rentabilidadMes: ingresos - egresos,
        nombreMes: nombre.charAt(0).toUpperCase() + nombre.slice(1) // Capitalizar
    };
  }, [movimientos]);

  // --- GUARDAR NUEVO MOVIMIENTO ---
  const handleGuardar = async () => {
    if (!form.monto || !form.descripcion || !form.cuenta_id) {
        return alert("Completa monto, descripción y cuenta.");
    }
    
    setSaving(true);
    const { data: { session } } = await supabase.auth.getSession();

    const nuevoMovimiento = {
        owner_id: session?.user.id,
        tipo: form.tipo,
        monto: Number(form.monto),
        moneda: form.moneda,
        fecha: form.fecha,
        referencia: form.descripcion,
        categoria: form.categoria,
        cuenta_id: form.cuenta_id,
        fuente: 'manual'
    };

    const { error } = await supabase.from("movimientos").insert(nuevoMovimiento);

    if (error) {
        alert("Error: " + error.message);
    } else {
        await cargarDatos(); 
        setModalOpen(false);
        setForm(prev => ({ ...prev, monto: "", descripcion: "" })); 
    }
    setSaving(false);
  };

  const movimientosFiltrados = movimientos.filter(m => filtro === "todos" ? true : m.tipo === filtro);

  if (loading) return <div className="p-10 text-gray-400 animate-pulse">Analizando finanzas...</div>;

  return (
    <div className="max-w-6xl mx-auto pb-20 p-6">
      
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-4">
        <div>
            <h1 className="text-3xl font-bold text-white mb-1">Finanzas de {nombreMes}</h1>
            <p className="text-gray-400 text-sm">Resumen de flujo de caja mensual.</p>
        </div>
        <button 
            onClick={() => setModalOpen(true)}
            className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/50 font-bold px-6 py-3 rounded-xl shadow-lg transition flex items-center gap-2"
        >
            💸 Registrar Gasto / Ingreso
        </button>
      </div>

      {/* TARJETAS RESUMEN (MES ACTUAL) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
        <div className="bg-[#161B22] border border-white/10 p-6 rounded-2xl">
          <p className="text-xs text-emerald-400 uppercase font-bold mb-2">Ingresos ({nombreMes})</p>
          <p className="text-3xl font-mono text-emerald-400 font-bold tracking-tight">+ ${totalIngresosMes.toLocaleString()}</p>
        </div>
        <div className="bg-[#161B22] border border-white/10 p-6 rounded-2xl">
          <p className="text-xs text-red-400 uppercase font-bold mb-2">Gastos ({nombreMes})</p>
          <p className="text-3xl font-mono text-red-400 font-bold tracking-tight">- ${totalEgresosMes.toLocaleString()}</p>
        </div>
        <div className="bg-gradient-to-br from-blue-900/20 to-black border border-blue-500/30 p-6 rounded-2xl relative overflow-hidden">
          <div className="relative z-10">
            <p className="text-xs text-blue-200 uppercase font-bold mb-2">Rentabilidad Neta</p>
            <p className="text-3xl font-mono text-white font-bold tracking-tight">$ {rentabilidadMes.toLocaleString()}</p>
          </div>
          <div className="absolute -right-4 -bottom-4 w-24 h-24 bg-blue-500/20 rounded-full blur-2xl"></div>
        </div>
      </div>

      {/* TABLA DE MOVIMIENTOS */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 border-b border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <h3 className="font-bold text-white">Todas las Transacciones</h3>
          
          <div className="flex bg-black/40 rounded-lg p-1 border border-white/5">
            <button onClick={() => setFiltro("todos")} className={`px-4 py-1.5 text-xs font-bold rounded-md transition ${filtro === "todos" ? "bg-white/10 text-white" : "text-gray-500 hover:text-gray-300"}`}>Todo</button>
            <button onClick={() => setFiltro("ingreso")} className={`px-4 py-1.5 text-xs font-bold rounded-md transition ${filtro === "ingreso" ? "bg-emerald-500/20 text-emerald-400" : "text-gray-500 hover:text-gray-300"}`}>Ingresos</button>
            <button onClick={() => setFiltro("egreso")} className={`px-4 py-1.5 text-xs font-bold rounded-md transition ${filtro === "egreso" ? "bg-red-500/20 text-red-400" : "text-gray-500 hover:text-gray-300"}`}>Gastos</button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-[#0F1115] text-gray-400 font-medium text-xs uppercase tracking-wider">
              <tr>
                <th className="p-4">Fecha</th>
                <th className="p-4">Concepto</th>
                <th className="p-4">Categoría</th>
                <th className="p-4">Cuenta</th>
                <th className="p-4 text-right">Monto</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {movimientosFiltrados.length === 0 ? (
                <tr><td colSpan={5} className="p-12 text-center text-gray-500 italic">No hay movimientos registrados aún.</td></tr>
              ) : (
                movimientosFiltrados.map((m) => (
                  <tr key={m.id} className="hover:bg-white/5 transition group">
                    <td className="p-4 text-gray-400 whitespace-nowrap font-mono text-xs">{m.fecha}</td>
                    <td className="p-4">
                      <div className="text-white font-bold">{m.referencia || m.nota || "Sin detalle"}</div>
                      <div className="text-xs text-gray-500 mt-0.5">
                        {m.cliente ? `Cliente: ${m.cliente.nombre}` : (m.fuente === 'manual' ? 'Registro Manual' : m.fuente)}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className={`px-2.5 py-1 rounded-md text-[10px] uppercase font-bold border ${
                        m.tipo === 'ingreso' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'
                      }`}>
                        {m.categoria || m.tipo}
                      </span>
                    </td>
                    <td className="p-4 text-gray-300 text-xs">{m.cuenta?.nombre || "—"}</td>
                    <td className={`p-4 text-right font-mono font-bold text-base ${m.tipo === 'ingreso' ? 'text-emerald-400' : 'text-red-400'}`}>
                      {m.tipo === 'ingreso' ? '+' : '-'} {Number(m.monto).toLocaleString()} <span className="text-[10px] text-gray-500 ml-1">{m.moneda}</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL NUEVO MOVIMIENTO */}
      {modalOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-in fade-in duration-200">
            <div className="bg-[#1C2128] border border-white/10 p-6 rounded-2xl w-full max-w-md shadow-2xl">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-white font-bold text-xl">Registrar Movimiento</h3>
                    <button onClick={() => setModalOpen(false)} className="text-gray-400 hover:text-white">✕</button>
                </div>
                
                <div className="space-y-4">
                    {/* Selector Tipo */}
                    <div className="grid grid-cols-2 gap-2 bg-black/40 p-1 rounded-xl border border-white/5">
                        <button 
                            onClick={() => setForm({...form, tipo: "ingreso"})}
                            className={`py-2 rounded-lg text-sm font-bold transition ${form.tipo === "ingreso" ? "bg-emerald-600 text-white shadow-lg" : "text-gray-500 hover:text-white"}`}
                        >
                            Ingreso 💰
                        </button>
                        <button 
                            onClick={() => setForm({...form, tipo: "egreso"})}
                            className={`py-2 rounded-lg text-sm font-bold transition ${form.tipo === "egreso" ? "bg-red-600 text-white shadow-lg" : "text-gray-500 hover:text-white"}`}
                        >
                            Gasto 💸
                        </button>
                    </div>

                    {/* Monto y Moneda */}
                    <div className="flex gap-2">
                        <div className="flex-1">
                            <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Monto</label>
                            <input type="number" value={form.monto} onChange={e => setForm({...form, monto: e.target.value})} placeholder="0.00" className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white font-mono text-lg outline-none focus:border-emerald-500 transition" />
                        </div>
                        <div className="w-24">
                            <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Moneda</label>
                            <select value={form.moneda} onChange={e => setForm({...form, moneda: e.target.value})} className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white outline-none h-[54px]">
                                <option value="COP">COP</option>
                                <option value="USD">USD</option>
                                <option value="EUR">EUR</option>
                                <option value="MXN">MXN</option>
                            </select>
                        </div>
                    </div>

                    {/* Descripción */}
                    <div>
                        <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Descripción</label>
                        <input value={form.descripcion} onChange={e => setForm({...form, descripcion: e.target.value})} placeholder="Ej: Pago de servidor, Café..." className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white outline-none focus:border-emerald-500 transition" />
                    </div>

                    {/* Cuenta y Fecha */}
                    <div className="grid grid-cols-2 gap-4">
                        <div>
                            <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Cuenta</label>
                            <select value={form.cuenta_id} onChange={e => setForm({...form, cuenta_id: e.target.value})} className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white outline-none">
                                <option value="">Seleccionar...</option>
                                {cuentas.map(c => (
                                    <option key={c.id} value={c.id}>{c.nombre} ({c.moneda})</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Fecha</label>
                            <input type="date" value={form.fecha} onChange={e => setForm({...form, fecha: e.target.value})} className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white outline-none" />
                        </div>
                    </div>

                    {/* Categoría */}
                    <div>
                        <label className="text-xs text-gray-400 font-bold ml-1 mb-1 block">Categoría</label>
                        <select value={form.categoria} onChange={e => setForm({...form, categoria: e.target.value})} className="w-full bg-[#0F1115] border border-gray-700 p-3 rounded-xl text-white outline-none">
                            <option value="general">General</option>
                            <option value="servicios">Servicios / Software</option>
                            <option value="equipo">Equipo / Hardware</option>
                            <option value="transporte">Transporte</option>
                            <option value="comida">Alimentación</option>
                            <option value="impuestos">Impuestos</option>
                            <option value="educacion">Educación</option>
                            <option value="salud">Salud</option>
                            <option value="ocio">Ocio</option>
                        </select>
                    </div>

                </div>

                <div className="flex justify-end gap-3 mt-8 pt-4 border-t border-white/5">
                    <button onClick={() => setModalOpen(false)} className="text-gray-400 hover:text-white px-4 py-3 font-medium transition">Cancelar</button>
                    <button onClick={handleGuardar} disabled={saving} className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 py-3 rounded-xl shadow-lg transition transform active:scale-95 disabled:opacity-50 disabled:scale-100">
                        {saving ? "Guardando..." : "Guardar Movimiento"}
                    </button>
                </div>
            </div>
        </div>
      )}

    </div>
  );
}