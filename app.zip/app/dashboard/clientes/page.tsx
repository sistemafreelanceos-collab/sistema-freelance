"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { supabase } from "../../../lib/supabaseClient";

type Plan = "gratis" | "premium";

type FrecuenciaPago = "semanal" | "quincenal" | "mensual" | "bimestral" | "anual";
type Moneda = "USD" | "COP" | "EUR" | "MXN";

type Cliente = {
  id: string;
  owner_id: string;

  nombre: string;
  email: string | null;
  telefono: string | null;
  empresa: string | null;
  estado: "activo" | "inactivo";
  nota: string | null;

  // pago
  monto: number | null;
  moneda: Moneda;
  frecuencia_pago: FrecuenciaPago;
  proximo_pago: string | null; // YYYY-MM-DD
  ultimo_pago?: string | null; // YYYY-MM-DD

  created_at: string;
  updated_at?: string;
};

type ProfilePlan = {
  plan: Plan;
  plan_status: "active" | "inactive";
};

const LIMITE_CLIENTES_GRATIS = 3;

// -------- helpers fechas
function addDays(date: Date, days: number) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}
function addMonths(date: Date, months: number) {
  const d = new Date(date);
  d.setMonth(d.getMonth() + months);
  return d;
}
function toISODate(date: Date) {
  return date.toISOString().slice(0, 10); // YYYY-MM-DD
}
function calcularProximoPago(baseISO: string, frecuencia: FrecuenciaPago) {
  const base = new Date(baseISO + "T00:00:00");
  let next = base;

  switch (frecuencia) {
    case "semanal":
      next = addDays(base, 7);
      break;
    case "quincenal":
      next = addDays(base, 15);
      break;
    case "mensual":
      next = addMonths(base, 1);
      break;
    case "bimestral":
      next = addMonths(base, 2);
      break;
    case "anual":
      next = addMonths(base, 12);
      break;
  }

  return toISODate(next);
}

export default function ClientesPage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [plan, setPlan] = useState<ProfilePlan | null>(null);
  const [clientes, setClientes] = useState<Cliente[]>([]);
  const [query, setQuery] = useState("");

  const [form, setForm] = useState({
    nombre: "",
    email: "",
    telefono: "",
    empresa: "",
    nota: "",
    monto: "",
    moneda: "USD" as Moneda,
    frecuencia_pago: "mensual" as FrecuenciaPago,
    proximo_pago: "",
  });

  // Modal editar
  const [editOpen, setEditOpen] = useState(false);
  const [editCliente, setEditCliente] = useState<Cliente | null>(null);

  const isPremium = plan?.plan === "premium" && plan?.plan_status === "active";

  const reachedFreeLimit = !isPremium && clientes.length >= LIMITE_CLIENTES_GRATIS;

  const clientesFiltrados = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return clientes;
    return clientes.filter((c) => {
      return (
        c.nombre.toLowerCase().includes(q) ||
        (c.email ?? "").toLowerCase().includes(q) ||
        (c.empresa ?? "").toLowerCase().includes(q)
      );
    });
  }, [clientes, query]);

  const resetForm = () => {
    setForm({
      nombre: "",
      email: "",
      telefono: "",
      empresa: "",
      nota: "",
      monto: "",
      moneda: "USD",
      frecuencia_pago: "mensual",
      proximo_pago: "",
    });
  };

  // ---- init: sesión, plan, clientes
  useEffect(() => {
    const init = async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      const session = sessionData.session;

      if (!session) {
        router.push("/");
        return;
      }

      const userId = session.user.id;

      const { data: profile, error: profileError } = await supabase
        .from("profiles")
        .select("plan,plan_status")
        .eq("id", userId)
        .single();

      if (profileError) {
        console.error(profileError);
        alert("No se pudo cargar tu plan (profiles).");
        setLoading(false);
        return;
      }

      setPlan(profile as ProfilePlan);

      const { data: rows, error } = await supabase
        .from("clientes")
        .select("*")
        .order("created_at", { ascending: false });

      if (error) {
        console.error(error);
        alert("No se pudieron cargar los clientes.");
        setLoading(false);
        return;
      }

      setClientes((rows as Cliente[]) ?? []);
      setLoading(false);
    };

    init();
  }, [router]);

  // ---- Validación límite GRATIS
  const puedeCrearCliente = async (): Promise<{ ok: boolean; reason?: string }> => {
    if (isPremium) return { ok: true };

    const { count, error } = await supabase
      .from("clientes")
      .select("id", { count: "exact", head: true });

    if (error) {
      console.error(error);
      return { ok: false, reason: "No se pudo validar el límite. Intenta de nuevo." };
    }

    const total = count ?? 0;
    if (total >= LIMITE_CLIENTES_GRATIS) {
      return {
        ok: false,
        reason: `Plan Gratis: máximo ${LIMITE_CLIENTES_GRATIS} clientes. Mejora a Premium para ilimitados.`,
      };
    }

    return { ok: true };
  };

  // ---- Crear
  const crearCliente = async () => {
    if (!form.nombre.trim()) {
      alert("El nombre es obligatorio.");
      return;
    }

    if (form.monto && Number.isNaN(Number(form.monto))) {
      alert("Monto inválido.");
      return;
    }

    setSaving(true);

    const permiso = await puedeCrearCliente();
    if (!permiso.ok) {
      setSaving(false);
      alert(permiso.reason);
      return;
    }

    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData.session;
    if (!session) {
      setSaving(false);
      router.push("/");
      return;
    }

    const payload = {
      owner_id: session.user.id,
      nombre: form.nombre.trim(),
      email: form.email.trim() || null,
      telefono: form.telefono.trim() || null,
      empresa: form.empresa.trim() || null,
      nota: form.nota.trim() || null,
      estado: "activo" as const,

      monto: form.monto ? Number(form.monto) : null,
      moneda: form.moneda,
      frecuencia_pago: form.frecuencia_pago,
      proximo_pago: form.proximo_pago || null,
    };

    const { data, error } = await supabase.from("clientes").insert(payload).select("*").single();

    setSaving(false);

    if (error) {
      console.error(error);
      alert("Error creando cliente: " + error.message);
      return;
    }

    setClientes((prev) => [data as Cliente, ...prev]);
    resetForm();
  };

  // ---- Desactivar
  const desactivarCliente = async (id: string) => {
    const { error } = await supabase.from("clientes").update({ estado: "inactivo" }).eq("id", id);

    if (error) {
      alert(error.message);
      return;
    }

    setClientes((prev) => prev.map((c) => (c.id === id ? { ...c, estado: "inactivo" } : c)));
  };

  // ---- Eliminar
  const eliminarCliente = async (id: string) => {
    if (!confirm("¿Eliminar este cliente?")) return;

    const { error } = await supabase.from("clientes").delete().eq("id", id);

    if (error) {
      alert(error.message);
      return;
    }

    setClientes((prev) => prev.filter((c) => c.id !== id));
  };

  // ---- Registrar pago (hoy -> próximo pago según frecuencia)
  const registrarPago = async (cliente: Cliente) => {
    const frecuencia = cliente.frecuencia_pago;
    if (!frecuencia) {
      alert("Este cliente no tiene frecuencia de pago.");
      return;
    }

    const hoyISO = toISODate(new Date());
    const nextISO = calcularProximoPago(hoyISO, frecuencia);

    const { error } = await supabase
      .from("clientes")
      .update({
        ultimo_pago: hoyISO,
        proximo_pago: nextISO,
      })
      .eq("id", cliente.id);

    if (error) {
      alert("No se pudo registrar el pago: " + error.message);
      return;
    }

    setClientes((prev) =>
      prev.map((c) =>
        c.id === cliente.id ? { ...c, ultimo_pago: hoyISO, proximo_pago: nextISO } : c
      )
    );

    alert(`Pago registrado ✅\nPróximo pago: ${nextISO}`);
  };

  // ---- Editar (modal)
  const openEdit = (cliente: Cliente) => {
    setEditCliente({ ...cliente });
    setEditOpen(true);
  };

  const closeEdit = () => {
    setEditOpen(false);
    setEditCliente(null);
  };

  const guardarEdicion = async () => {
    if (!editCliente) return;

    if (!editCliente.nombre.trim()) {
      alert("El nombre es obligatorio.");
      return;
    }

    const { error } = await supabase
      .from("clientes")
      .update({
        nombre: editCliente.nombre.trim(),
        email: editCliente.email?.trim() || null,
        telefono: editCliente.telefono?.trim() || null,
        empresa: editCliente.empresa?.trim() || null,
        nota: editCliente.nota?.trim() || null,

        monto: editCliente.monto ?? null,
        moneda: editCliente.moneda,
        frecuencia_pago: editCliente.frecuencia_pago,
        proximo_pago: editCliente.proximo_pago || null,
      })
      .eq("id", editCliente.id);

    if (error) {
      alert("Error guardando: " + error.message);
      return;
    }

    setClientes((prev) => prev.map((c) => (c.id === editCliente.id ? editCliente : c)));
    closeEdit();
  };

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto">
        <div className="bg-[#161B22] border border-white/10 rounded-2xl p-8 text-gray-300">
          Cargando clientes...
        </div>
      </div>
    );
  }

  const contadorTexto = isPremium
    ? `${clientes.length} clientes`
    : `${clientes.length}/${LIMITE_CLIENTES_GRATIS} clientes (Gratis)`;

  return (
    <div className="max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Clientes</h1>
          <p className="text-gray-400 text-sm">{contadorTexto}</p>
        </div>

        {reachedFreeLimit && (
          <Link
            href="/dashboard/suscripcion"
            className="bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-200 border border-yellow-500/40 text-xs font-bold py-2 px-4 rounded-lg transition"
          >
            Mejorar a Premium
          </Link>
        )}
      </div>

      {/* Buscador */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl p-4 mb-6">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Buscar por nombre, email o empresa..."
          className="w-full bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
        />
      </div>

      {/* Crear cliente */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl p-6 mb-8">
        <h2 className="text-lg font-bold text-white mb-4">Agregar cliente</h2>

        {reachedFreeLimit && (
          <div className="mb-4 text-sm text-yellow-200 bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3">
            Llegaste al límite del Plan Gratis. Ve a <b>Suscripción</b> para desbloquear clientes ilimitados.
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <input
            value={form.nombre}
            onChange={(e) => setForm({ ...form, nombre: e.target.value })}
            placeholder="Nombre (obligatorio)"
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          <input
            value={form.empresa}
            onChange={(e) => setForm({ ...form, empresa: e.target.value })}
            placeholder="Empresa / Marca"
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          <input
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
            placeholder="Email"
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          <input
            value={form.telefono}
            onChange={(e) => setForm({ ...form, telefono: e.target.value })}
            placeholder="Teléfono"
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          {/* Pago */}
          <input
            value={form.monto}
            onChange={(e) => setForm({ ...form, monto: e.target.value })}
            placeholder="Monto (ej: 650)"
            inputMode="decimal"
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          <select
            value={form.moneda}
            onChange={(e) => setForm({ ...form, moneda: e.target.value as Moneda })}
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          >
            <option value="USD">USD</option>
            <option value="COP">COP</option>
            <option value="EUR">EUR</option>
            <option value="MXN">MXN</option>
          </select>

          <select
            value={form.frecuencia_pago}
            onChange={(e) => setForm({ ...form, frecuencia_pago: e.target.value as FrecuenciaPago })}
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          >
            <option value="semanal">Semanal</option>
            <option value="quincenal">Quincenal</option>
            <option value="mensual">Mensual</option>
            <option value="bimestral">Bimestral</option>
            <option value="anual">Anual</option>
          </select>

          <input
            type="date"
            value={form.proximo_pago}
            onChange={(e) => setForm({ ...form, proximo_pago: e.target.value })}
            className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
          />

          <textarea
            value={form.nota}
            onChange={(e) => setForm({ ...form, nota: e.target.value })}
            placeholder="Nota (opcional)"
            className="md:col-span-2 bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition min-h-[90px]"
          />
        </div>

        <div className="mt-4 flex justify-end">
          <button
            onClick={crearCliente}
            disabled={saving || reachedFreeLimit}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-3 px-6 rounded-xl transition disabled:opacity-60"
          >
            {saving ? "Guardando..." : "Crear cliente"}
          </button>
        </div>
      </div>

      {/* Lista */}
      <div className="bg-[#161B22] border border-white/10 rounded-2xl overflow-hidden">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between">
          <h3 className="text-white font-bold">Listado</h3>
          <span className="text-xs text-gray-400">{clientesFiltrados.length} resultados</span>
        </div>

        {clientesFiltrados.length === 0 ? (
          <div className="p-8 text-gray-400">No hay clientes todavía.</div>
        ) : (
          <div className="divide-y divide-white/10">
            {clientesFiltrados.map((c) => (
              <div key={c.id} className="p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-white font-bold">{c.nombre}</p>
                    <span
                      className={`text-[10px] px-2 py-1 rounded-full border ${
                        c.estado === "activo"
                          ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                          : "bg-gray-500/10 text-gray-300 border-white/10"
                      }`}
                    >
                      {c.estado}
                    </span>
                  </div>

                  <p className="text-sm text-gray-400">
                    {(c.empresa ?? "—")} • {(c.email ?? "—")} • {(c.telefono ?? "—")}
                  </p>

                  <p className="text-xs text-gray-500 mt-1">
                    Pago: {c.monto ? `${c.monto} ${c.moneda}` : "—"} • {c.frecuencia_pago ?? "—"} • Próximo:{" "}
                    {c.proximo_pago ?? "—"} • Último: {c.ultimo_pago ?? "—"}
                  </p>

                  {c.nota && <p className="text-xs text-gray-500 mt-1">{c.nota}</p>}
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => registrarPago(c)}
                    className="text-xs px-3 py-2 rounded-lg border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/10 transition"
                  >
                    Registrar pago
                  </button>

                  <button
                    onClick={() => openEdit(c)}
                    className="text-xs px-3 py-2 rounded-lg border border-white/10 text-gray-200 hover:bg-white/5 transition"
                  >
                    Editar
                  </button>

                  {c.estado === "activo" && (
                    <button
                      onClick={() => desactivarCliente(c.id)}
                      className="text-xs px-3 py-2 rounded-lg border border-white/10 text-gray-200 hover:bg-white/5 transition"
                    >
                      Desactivar
                    </button>
                  )}

                  <button
                    onClick={() => eliminarCliente(c.id)}
                    className="text-xs px-3 py-2 rounded-lg border border-red-500/30 text-red-300 hover:bg-red-500/10 transition"
                  >
                    Eliminar
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* MODAL EDITAR */}
      {editOpen && editCliente && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="w-full max-w-xl bg-[#161B22] border border-white/10 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Editar cliente</h3>
              <button onClick={closeEdit} className="text-gray-400 hover:text-white">
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                value={editCliente.nombre}
                onChange={(e) => setEditCliente({ ...editCliente, nombre: e.target.value })}
                placeholder="Nombre"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={editCliente.empresa ?? ""}
                onChange={(e) => setEditCliente({ ...editCliente, empresa: e.target.value })}
                placeholder="Empresa"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={editCliente.email ?? ""}
                onChange={(e) => setEditCliente({ ...editCliente, email: e.target.value })}
                placeholder="Email"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={editCliente.telefono ?? ""}
                onChange={(e) => setEditCliente({ ...editCliente, telefono: e.target.value })}
                placeholder="Teléfono"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <input
                value={editCliente.monto ?? ""}
                onChange={(e) =>
                  setEditCliente({
                    ...editCliente,
                    monto: e.target.value === "" ? null : Number(e.target.value),
                  })
                }
                placeholder="Monto"
                inputMode="decimal"
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <select
                value={editCliente.moneda}
                onChange={(e) => setEditCliente({ ...editCliente, moneda: e.target.value as Moneda })}
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              >
                <option value="USD">USD</option>
                <option value="COP">COP</option>
                <option value="EUR">EUR</option>
                <option value="MXN">MXN</option>
              </select>

              <select
                value={editCliente.frecuencia_pago}
                onChange={(e) =>
                  setEditCliente({ ...editCliente, frecuencia_pago: e.target.value as FrecuenciaPago })
                }
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              >
                <option value="semanal">Semanal</option>
                <option value="quincenal">Quincenal</option>
                <option value="mensual">Mensual</option>
                <option value="bimestral">Bimestral</option>
                <option value="anual">Anual</option>
              </select>

              <input
                type="date"
                value={editCliente.proximo_pago ?? ""}
                onChange={(e) => setEditCliente({ ...editCliente, proximo_pago: e.target.value })}
                className="bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition"
              />

              <textarea
                value={editCliente.nota ?? ""}
                onChange={(e) => setEditCliente({ ...editCliente, nota: e.target.value })}
                placeholder="Nota"
                className="md:col-span-2 bg-[#0F1115] border border-gray-700 rounded-lg px-4 py-3 text-white outline-none focus:border-emerald-500 transition min-h-[90px]"
              />
            </div>

            <div className="mt-5 flex justify-end gap-2">
              <button
                onClick={closeEdit}
                className="px-4 py-2 rounded-lg border border-white/10 text-gray-200 hover:bg-white/5 transition"
              >
                Cancelar
              </button>
              <button
                onClick={guardarEdicion}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition"
              >
                Guardar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
