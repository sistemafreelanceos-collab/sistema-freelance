"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../../lib/supabaseClient";

export default function DashboardPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [email, setEmail] = useState("");

  useEffect(() => {
    const checkSession = async () => {
      const { data } = await supabase.auth.getSession();

      if (!data.session) {
        router.push("/");
        return;
      }

      setEmail(data.session.user.email ?? "");
      setLoading(false);
    };

    checkSession();
  }, [router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-white">
        Cargando...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0F1115] text-white p-8">
      <h1 className="text-2xl font-bold mb-4">
        Bienvenido {email}
      </h1>

      <button
        onClick={async () => {
          await supabase.auth.signOut();
          router.push("/");
        }}
        className="mt-6 bg-red-600 px-4 py-2 rounded"
      >
        Cerrar sesión
      </button>
    </div>
  );
}
  