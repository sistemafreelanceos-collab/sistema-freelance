export default function Finanzas() {
  return (
    <main className="min-h-screen p-24 bg-gray-900 text-white">
      <h1 className="text-4xl font-bold text-emerald-400 mb-8">💰 Tablero Financiero</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Tarjeta 1 */}
        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <h2 className="text-gray-400">Meta Mensual</h2>
          <p className="text-3xl font-bold text-white">$2,500 USD</p>
        </div>

        {/* Tarjeta 2 */}
        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <h2 className="text-gray-400">Progreso Actual</h2>
          <p className="text-3xl font-bold text-yellow-400">0%</p>
        </div>

        {/* Tarjeta 3 */}
        <div className="bg-gray-800 p-6 rounded-xl border border-gray-700">
          <h2 className="text-gray-400">Destino</h2>
          <p className="text-3xl font-bold text-blue-400">Florianópolis 🏖️</p>
        </div>
      </div>
    </main>
  );
}