"use client";
import { useState, useEffect } from "react";
import Link from "next/link"; // 👈 1. IMPORTANTE: Importamos el Link

export default function Clientes() {
  const [clientes, setClientes] = useState([
    { id: 1, nombre: "Gabriela", empresa: "Gaby Corp", presupuesto: 500 },
  ]);

  const [nuevoNombre, setNuevoNombre] = useState("");
  const [nuevoPresupuesto, setNuevoPresupuesto] = useState("");

  useEffect(() => {
    const guardados = localStorage.getItem("mis-clientes-v1");
    if (guardados) setClientes(JSON.parse(guardados));
  }, []);

  useEffect(() => {
    localStorage.setItem("mis-clientes-v1", JSON.stringify(clientes));
  }, [clientes]);

  const agregarCliente = () => {
    if (nuevoNombre === "" || nuevoPresupuesto === "") return;
    
    const nuevoCliente = {
      id: Date.now(),
      nombre: nuevoNombre,
      empresa: "Prospecto Nuevo",
      presupuesto: Number(nuevoPresupuesto),
    };
    
    setClientes([...clientes, nuevoCliente]);
    setNuevoNombre("");
    setNuevoPresupuesto("");
  };

  const borrarCliente = (id: number) => {
    setClientes(clientes.filter(c => c.id !== id));
  };

  const totalFacturacion = clientes.reduce((total, cliente) => total + cliente.presupuesto, 0);

  return (
    <main className="min-h-screen p-24 bg-gray-900 text-white">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold text-emerald-400">👥 Mis Clientes</h1>
        <div className="bg-emerald-900/50 p-4 rounded-lg border border-emerald-500/30">
          <p className="text-sm text-emerald-200">Total en Cartera</p>
          <p className="text-3xl font-bold text-white">${totalFacturacion} USD</p>
        </div>
      </div>

      <div className="flex gap-4 mb-8 bg-gray-800 p-4 rounded-xl border border-gray-700">
        <input
          type="text"
          placeholder="Nombre del cliente..."
          className="flex-1 p-3 rounded bg-gray-900 text-white border border-gray-600 focus:border-emerald-500 outline-none"
          value={nuevoNombre}
          onChange={(e) => setNuevoNombre(e.target.value)}
        />
        <input
          type="number"
          placeholder="$ Presupuesto"
          className="w-40 p-3 rounded bg-gray-900 text-white border border-gray-600 focus:border-emerald-500 outline-none"
          value={nuevoPresupuesto}
          onChange={(e) => setNuevoPresupuesto(e.target.value)}
        />
        <button
          onClick={agregarCliente}
          className="bg-emerald-600 px-8 py-3 rounded font-bold hover:bg-emerald-500 transition shadow-lg shadow-emerald-900/20"
        >
          + Vender
        </button>
      </div>

      <div className="grid gap-4">
        {clientes.map((cliente) => (
          <div key={cliente.id} className="bg-gray-800 p-4 rounded-xl flex justify-between items-center border border-gray-700 hover:border-emerald-500/30 transition group">
            
            {/* 👇 AQUÍ ESTÁ EL CAMBIO: El nombre ahora es un Link */}
            <Link href={`/clientes/${cliente.nombre}`} className="flex-1 cursor-pointer">
              <div>
                <h2 className="text-xl font-bold text-white group-hover:text-emerald-300 transition flex items-center gap-2">
                  {cliente.nombre} 
                  <span className="text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full group-hover:bg-emerald-900 group-hover:text-emerald-300">Ver Perfil ➡️</span>
                </h2>
                <p className="text-gray-400 text-sm">{cliente.empresa}</p>
              </div>
            </Link>
            {/* 👆 FIN DEL CAMBIO */}

            <div className="flex items-center gap-4">
              <span className="text-emerald-400 font-mono font-bold text-xl">
                ${cliente.presupuesto} USD
              </span>
              <button 
                onClick={() => borrarCliente(cliente.id)}
                className="text-gray-600 hover:text-red-400 p-2 transition z-10" // z-10 para que el click no choque con el link
              >
                🗑️
              </button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}