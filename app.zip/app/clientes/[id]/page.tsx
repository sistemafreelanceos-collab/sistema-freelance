import {ChatIA} from "../../components/ChatIA"; // 👈 Importamos el chat que acabas de crear

export default async function DashboardCliente({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  // Convertimos el "id" (gabriela) a un nombre bonito (Gabriela)
  const nombreLimpio = decodeURIComponent(id).charAt(0).toUpperCase() + decodeURIComponent(id).slice(1);

  return (
    <main className="min-h-screen p-24 bg-gray-950 text-white">
      <div className="border-b border-gray-800 pb-8 mb-8">
        <h1 className="text-4xl font-bold text-emerald-400 mb-2">
          🤖 Panel de Control IA
        </h1>
        <p className="text-xl text-gray-400">
          Gestionando cliente: <span className="text-white font-mono">{nombreLimpio}</span>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* ZONA 1: EL CHAT REAL (Aquí conectamos el componente) */}
        <div className="h-[500px]">
          <h2 className="text-xl font-bold mb-4 text-emerald-200">💬 Asistente Activo</h2>
          {/* 👇 AQUÍ ESTÁ LA MAGIA QUE FALTABA 👇 */}
          <ChatIA nombreCliente={nombreLimpio} />
        </div>

        {/* ZONA 2: Datos */}
        <div className="space-y-6">
          <div className="bg-gray-900 p-6 rounded-xl border border-gray-700">
            <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">Estado del Proyecto</h3>
            <p className="text-2xl font-bold text-yellow-400">⚡ IA Conectada</p>
          </div>

          <div className="bg-gray-900 p-6 rounded-xl border border-gray-700">
            <h3 className="text-gray-400 text-sm uppercase tracking-wider mb-1">Costo por Token</h3>
            <p className="text-2xl font-bold text-white">$0.0000 USD</p>
            <p className="text-xs text-gray-500">(La API de prueba es gratis)</p>
          </div>
        </div>

      </div>
    </main>
  );
}