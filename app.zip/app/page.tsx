"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "../lib/supabaseClient";

export default function LoginPage() {
  const router = useRouter();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // ✅ Si ya hay sesión, manda al dashboard
  useEffect(() => {
    const checkSession = async () => {
      const { data } = await supabase.auth.getSession();
      if (data.session) {
        console.log("SESSION ACTIVA:", data.session.user);
        router.push("/dashboard");
      }
    };
    checkSession();
  }, [router]);

  // ✅ LOGIN con Email/Password (Supabase real)
  const handleLoginEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    setLoading(false);

    if (error) {
      alert(error.message);
      return;
    }

    console.log("LOGGED USER (EMAIL):", data.user);
    router.push("/dashboard");
  };

  // ✅ LOGIN con Google
  const handleLoginGoogle = async () => {
    setLoading(true);

    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: {
        redirectTo: `${location.origin}/dashboard`,
      },
    });

    if (error) {
      alert(error.message);
      setLoading(false);
    }
  };

  // ✅ LOGIN con Apple
  const handleLoginApple = async () => {
    setLoading(true);

    const { error } = await supabase.auth.signInWithOAuth({
      provider: "apple",
      options: {
        redirectTo: `${location.origin}/dashboard`,
      },
    });

    if (error) {
      alert(error.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0F1115] text-white">
      <div className="w-full max-w-md bg-[#161B22] p-8 rounded-2xl border border-gray-800">

        <h1 className="text-3xl font-bold text-center mb-6">
          Freelance<span className="text-emerald-500">OS</span>
        </h1>

        {/* EMAIL LOGIN */}
        <form onSubmit={handleLoginEmail} className="space-y-4">
          <input
            type="email"
            placeholder="Correo"
            required
            className="w-full px-4 py-3 rounded bg-[#0F1115] border border-gray-700"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />

          <input
            type="password"
            placeholder="Contraseña"
            required
            className="w-full px-4 py-3 rounded bg-[#0F1115] border border-gray-700"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-emerald-600 py-3 rounded font-bold disabled:opacity-60"
          >
            {loading ? "Entrando..." : "Iniciar sesión"}
          </button>
        </form>

        {/* DIVISOR */}
        <div className="my-6 flex items-center gap-3">
          <div className="flex-1 h-px bg-gray-700" />
          <span className="text-xs text-gray-400">o continúa con</span>
          <div className="flex-1 h-px bg-gray-700" />
        </div>

        {/* PROVIDERS */}
        <div className="space-y-3">
          <button
            type="button"
            disabled={loading}
            onClick={handleLoginGoogle}
            className="w-full bg-white text-black py-3 rounded font-semibold disabled:opacity-60"
          >
            Continuar con Google
          </button>

          <button
            type="button"
            disabled={loading}
            onClick={handleLoginApple}
            className="w-full bg-black text-white py-3 rounded font-semibold border border-gray-700 disabled:opacity-60"
          >
            Continuar con Apple
          </button>
        </div>
      </div>
    </div>
  );
}
